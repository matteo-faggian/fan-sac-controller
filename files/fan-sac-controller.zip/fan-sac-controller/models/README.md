# Modelli

| File | Esperimento | Ambiente da usare | Note |
|---|---|---|---|
| `sac_E.zip` | E: reward con \|e\|, γ = 0.99, i_max = 0.5, c_min = 0.05 | `controller/archivio/env_fan_E.py` | 5 osservazioni. Testato sul banco: RMS 0.067–0.085 N |

**Importante:** un modello funziona solo con l'ambiente con cui è stato addestrato, perché le
osservazioni devono avere lo stesso numero, lo stesso ordine e la stessa normalizzazione.
Per provare `sac_E.zip` sul banco, copia `archivio/env_fan_E.py` come `env_fan.py` nella
cartella da cui lanci `controllo_reale.py`.

Il modello si carica sempre con l'estensione esplicita:
`SAC.load("sac_E.zip")`. Senza `.zip`, se esiste una cartella con lo stesso nome,
Windows dà `PermissionError`.
